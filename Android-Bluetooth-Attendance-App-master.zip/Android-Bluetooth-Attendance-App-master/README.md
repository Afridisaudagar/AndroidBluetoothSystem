# BluetoothAttendanceApp
A check in system for attendance that relies on Bluetooth connections to validate the meeting.

The app has two sides. The “host” side sets up the meeting, opening their phone to bluetooth connections during the time, and stores the names of the people that show up to the meeting. Once he concludes it, it outputs those names and a few extras.
The “attendee” to the meeting uses their phone to have a saved name to pass to the host. They approve the bluetooth connection and pass on the information to the host for their list.

