package com.example.student.bluetoothattendanceapp;

public class Prospective {

    private String[] people;


    public Prospective(String[] people){
        this.people = people;
    }

    public String[] getPeople() {
        return people;
    }

    public void setPeople(String[] people) {
        this.people = people;
    }
}


