package com.example.student.bluetoothattendanceapp.listener;

import android.view.View;


public interface RecyclerItemClickListener {

    void onItemClick(int position, View view);
}
