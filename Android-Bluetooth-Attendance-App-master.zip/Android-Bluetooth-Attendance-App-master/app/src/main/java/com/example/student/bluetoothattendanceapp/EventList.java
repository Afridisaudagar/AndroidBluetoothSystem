package com.example.student.bluetoothattendanceapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class EventList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_event_list);
    }
}
