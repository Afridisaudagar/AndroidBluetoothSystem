package com.example.student.bluetoothattendanceapp.constant;


public class MeetingField {

    public static final String TABLE_NAME = "contact";
    public static final String COLUMN_ID = "contact_id";
    public static final String COLUMN_NAME = "contact_name";
    public static final String COLUMN_PHONE = "contact_phone";

}
